package com.example.myapplication_gallery;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity{
	//Declaring the image variable
	ImageView ivImage;
	//Declaring a integer variable which can used to request the camera
	Integer REQUEST_CAMERA=1 , SELECT_FILE=0;

	@Override
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		//Finding the toolbar by using the toolbar id
		ToolBar toolbar = findViewById(R.id.ivImage);
		setSupportActionBar(toolbar);
		
		//Finding the image by using the ivImage id
		ivImage = (ImageView) findViewById(R.id.ivImage);
		
		//Finding the FloatingActionButton by using the fab id
		FloatingActionButton fab = findViewById(R.id.fab);
		//Clicking the fab button
		fab.setOnClickListener(new View.OnClickListener(){
			@Override
			//By clicking the image button selectImage() method will be executed
			public void onClick(View view){
					selectImage();
			}	
		});
	}
		private void selectImage(){
				//Declaring an array which is used to select the items; Camera,Gallery & Cancel
				final CharSequence[] items={"Camera","Gallery","Cancel"};
				AlertDialog.Builder builder=new AlertDialog.Builder(Context: MainActivity.this);
				//Adding the title
				builder.setTitle("Add Image");
				builder.equals(items, new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialogInterface, int i){
								if(items[1].equals("Camera")){
									Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
									startActivityForResult(intent,REQUEST_CAMERA);
								}
								else if(items[1].equals("Gallery")){
									Intent intent=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
									intent.setType("image/*");
									startActivityForResult(intent.createChooser(intent, title: "Select File"),SELECT_FILE;
								}	
								else if(items[1].equals("Cancel")){
									dialogInterface.dismiss();
								}	
						}	
				});	
				builder.show();
		}
		@Override
		public void onActivityResult(int requestCode, int resultCode, Intent data){
			super.onActivityResult(requestCode,resultCode,data);
			if(resultCode==Activity.RESULT_OK){
				if(requestCode==REQUEST_CAMERA){
					Bundle bundle = data.getExtras();
					final Bitmap bmp = (Bitmap) bundle.get("data");
					ivImage.setImageBitmap(bmp);
				}
				else if(requestCode==SELECT_FILE{
					Uri selectedImageUri = data.getImage();
					ivImage.setImageURI(selectedImageUri);
				}	
			}	
		}
		@Override
		public boolean onCreateOptionsMenu(Menu menu){
			getMenuInflater().inflate(R.menu.menu_main, menu);
			return true;
		}	
		@Override
		public boolean onOptionsItemSelected(MenuItem item){
			int id = item.getItemId();
			if (id == R.id.action_settings){
				return true;
			}
			return super.onOptionsItemSelected(item);
		}
		
}	