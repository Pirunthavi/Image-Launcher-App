package com.example.myapplication_gallery;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Front extends AppCompatActivity{
	
	@Override
	protected void onCreate (Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_front);
		
		//Clicking the image button
		ImageButton btn=(ImageButton) findViewById(R.id.btn);
		btn.setOnClickListener(new View.OnClickListener){
			@Override
			public void onClick (View view){
				//Intent to executing the main class
				Intent intent=new Intent(getApplicationContext(),MainActivity.class);
				//Start the intent
				StartActivity(intent);
			}	
		}	
	}	
}	